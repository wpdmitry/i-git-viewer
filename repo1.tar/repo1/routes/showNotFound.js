module.exports = (req, res) => {
    res.send('Данный путь не найден');
};
